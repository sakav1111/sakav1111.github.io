---
name: Feature request
about: Suggest an idea for this project
title: 'Feature request: '
labels: ''
assignees: ''

---

<!-- Prefer English -->

## Description

[Description of the feature]
