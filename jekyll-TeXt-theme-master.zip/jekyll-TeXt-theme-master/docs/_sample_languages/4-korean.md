---
title: 한국어 (Korean)
key: lang-ko
permalink: /languages/korean.html
cover: /docs/assets/images/languages/lang-ko.jpg
lang: ko
---

한국어.

<!--more-->

*_config.yml* or front matter:

```yml
lang: ko
lang: ko-KR
```
