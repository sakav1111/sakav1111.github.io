tree -I '.*|_site|docs|node_modules|screenshots|test|Gemfile.lock|*.gem|CHANGELOG.md|HOW_TO_RELEASE.md|LICENSE|README*|screenshot.*'  --dirsfirst
